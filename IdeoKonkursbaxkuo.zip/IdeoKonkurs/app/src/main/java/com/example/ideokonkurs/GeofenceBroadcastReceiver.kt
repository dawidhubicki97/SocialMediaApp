package com.example.ideokonkurs

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.provider.Settings.Global.getString
import android.util.Log
import android.widget.Toast
import androidx.constraintlayout.widget.Constraints.TAG
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.GeofenceStatusCodes
import com.google.android.gms.location.GeofencingEvent

class GeofenceBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context?, intent: Intent?) {

        val geofencingEvent = GeofencingEvent.fromIntent(intent)
        if (geofencingEvent.hasError()) {
            Log.d("costam", "ajajajaja")
            return
        }
        val geofenceTransition = geofencingEvent.geofenceTransition
        if (geofenceTransition == Geofence.GEOFENCE_TRANSITION_ENTER) {
            geofencingEvent.triggeringGeofences.forEach {
                Log.d("costam", "wlazlo")
                val myToast = Toast.makeText(context,"wlazlo",Toast.LENGTH_SHORT)
                myToast.show()

                val intent=Intent("googlegeofence")
                intent.putExtra("geofencename",it.requestId)
                intent.putExtra("action",1)
                LocalBroadcastManager.getInstance(context!!).sendBroadcast(intent)
            }
        }
        if(geofenceTransition == Geofence.GEOFENCE_TRANSITION_EXIT){
            geofencingEvent.triggeringGeofences.forEach {
                Log.d("costam", "wylazlo")
                val myToast = Toast.makeText(context,"wylazlo",Toast.LENGTH_SHORT)
                myToast.show()
                val intent=Intent("googlegeofence")
                intent.putExtra("geofencename",it.requestId)
                intent.putExtra("action",0)
                LocalBroadcastManager.getInstance(context!!).sendBroadcast(intent)
            }
        }
        else {
            val myToast = Toast.makeText(context,"ajaja",Toast.LENGTH_SHORT)
            myToast.show()
            Log.d("costam", "ajajajajadwa")

        }
    }
}