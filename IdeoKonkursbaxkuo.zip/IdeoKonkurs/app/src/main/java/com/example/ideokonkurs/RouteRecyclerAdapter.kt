package com.example.ideokonkurs

import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.ideokonkurs.fragments.MyMapFragment
import com.example.ideokonkurs.models.RouteItem
import kotlinx.android.synthetic.main.layout_route_list_item.view.*


class RouteRecyclerAdapter: RecyclerView.Adapter<RecyclerView.ViewHolder>() {
    private var items: List<RouteItem> = ArrayList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return RouteViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.layout_route_list_item,parent,false))
    }

    override fun getItemCount(): Int {
        return items.size
    }
    fun submitList(routeList: List<RouteItem>){
        items = routeList
    }
    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        when(holder){
            is RouteViewHolder->{
                holder.bind(items.get(position))

            }
        }

    }
    class RouteViewHolder constructor(itemView: View):RecyclerView.ViewHolder(itemView){
        val route_image=itemView.route_image
        val route_description=itemView.route_description
        val route_name=itemView.route_name
        var routeitem:RouteItem?=null
        var routeid:Int?=null
        fun bind(routeItem: RouteItem){
            routeitem=routeItem
            routeid=routeItem.id
            route_description.setText(routeItem.description)
            route_name.setText(routeItem.name)
            val requestOptions=RequestOptions().placeholder(R.drawable.ic_launcher_background).error(R.drawable.ic_launcher_background).override(400,300).centerCrop()
            Glide.with(itemView.context).applyDefaultRequestOptions(requestOptions).load(routeItem.image).into(route_image)
        }
        init {
            itemView.setOnClickListener {
                val zmienna=it.context as MainActivity
                zmienna.replaceFragment(MyMapFragment(),routeid)

            }
        }

    }

}