package com.example.ideokonkurs.fragments

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.AsyncTask
import android.os.Bundle

import android.provider.Settings
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup

import androidx.fragment.app.Fragment
import androidx.localbroadcastmanager.content.LocalBroadcastManager
import com.example.ideokonkurs.*
import com.example.ideokonkurs.R
import com.example.ideokonkurs.models.*
import com.example.ideokonkurs.models.Routes
import com.firebase.geofire.GeoFire
import com.firebase.geofire.GeoLocation
import com.google.android.gms.location.Geofence
import com.google.android.gms.location.Geofence.NEVER_EXPIRE
import com.google.android.gms.location.GeofencingClient
import com.google.android.gms.location.GeofencingRequest
import com.google.android.gms.location.LocationServices
import com.google.android.gms.maps.*
import com.google.android.gms.maps.model.*
import com.google.android.material.navigation.NavigationView
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import com.google.gson.Gson
import com.google.maps.android.MarkerManager
import com.google.maps.android.PolyUtil
import kotlinx.android.synthetic.main.fragment_map.*
import okhttp3.*
import java.io.IOException
import java.lang.Exception
import kotlin.math.roundToInt

class MyMapFragment: Fragment(),OnMapReadyCallback {




    var googleMap: GoogleMap?=null
    var points: MutableList<LatLng> = ArrayList()
    var offRoutePoints: MutableList<LatLng> = ArrayList()
    var routepoints: MutableList<LatLng> = ArrayList()
    var places: MutableList<Place> = ArrayList()
    private var trafficTime:Int?=null
    private var markers:MutableList<Marker> = ArrayList()
    private var routeline: Polyline?=null
    private var line: Polyline?=null
    private var offRouteLine: Polyline?=null
    private var thisactivity:Activity?=null
    var geofenceList:MutableList<Geofence> = ArrayList()
    lateinit var geofencingClient: GeofencingClient

    private val geofencePendingIntent: PendingIntent by lazy {
        val intent = Intent(activity, GeofenceBroadcastReceiver::class.java)
        PendingIntent.getBroadcast(activity, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT)

    }

    override fun onAttach(context: Context?) {
        super.onAttach(context)
        Log.d("sciezka","onAttach")

    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Log.d("sciezka","onSaveInstanceState")


    }


    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        Log.d("sciezka","onCreateView")
        val root = inflater.inflate(R.layout.fragment_map, container, false)
        val mapview=root!!.findViewById<MapView>(R.id.map)
        mapview.onCreate(savedInstanceState)
        mapview.onResume()
        mapview.getMapAsync(this)
        geofencingClient = LocationServices.getGeofencingClient(activity!!.applicationContext)

        return root
    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        val routeid=arguments?.getInt("routeid")
        retainInstance=true
        Log.d("sciezka","onActivityCreated")


        this.thisactivity=activity
        if(routeid!=null && routepoints.isEmpty()){
            fetchPointsFromDatabase(routeid)
        }
       val broadcastmanager=LocalBroadcastManager.getInstance(context!!)
        val googleReciever=GoogleReciever()
        broadcastmanager.registerReceiver(googleReciever, IntentFilter("googlegeofence"))

    }
    inner class GoogleReciever:BroadcastReceiver(){

        override fun onReceive(p0: Context?, p1: Intent?) {
           val name= p1?.getStringExtra("geofencename")
            val action=p1?.getIntExtra("action",3)
            for (i in places){
                if(i.name==name && action==1){
                    val markeroptions=MarkerOptions().position(LatLng(i.latitude,i.longitude)).title(i.name).icon(BitmapDescriptorFactory.fromResource(R.drawable.star))
                    val marker=googleMap?.addMarker(markeroptions)
                    marker?.showInfoWindow()
                    markers.add(marker!!)
                }
                if(i.name==name && action==0){
                    markers.get(0).remove()
                }
            }

        }


    }

    @SuppressLint("MissingPermission")
    override fun onMapReady(p0: GoogleMap?) {
        Log.d("sciezka","onMapReady")
        googleMap= p0!!
        googleMap!!.isMyLocationEnabled=true


        if(routepoints.isNotEmpty()){
            showTrafficTime()
            drawRoutePolyline()
            addGeoFencingToMap()
            googleMap!!.moveCamera(CameraUpdateFactory.newLatLngZoom(routepoints.get(0), 16f))
        }
        if(offRoutePoints.isNotEmpty()){
            drawOffRouteLine()
        }


    }

    @SuppressLint("MissingPermission")
    private fun addGeoFencingToMap(){
        geofenceList.clear()

        for(i in places) {
            val circleoptions=CircleOptions().center(LatLng(i.latitude,i.longitude)).strokeColor(Color.argb(50,70,70,70))
                .fillColor(Color.argb(100,150,150,150)).radius(40.0)
            googleMap?.addCircle(circleoptions)
            geofenceList.add(
                Geofence.Builder()
                    .setRequestId(i.name)
                    .setCircularRegion(
                        i.latitude,
                        i.longitude,
                        40f
                    )
                    .setExpirationDuration(NEVER_EXPIRE)
                    .setTransitionTypes(Geofence.GEOFENCE_TRANSITION_ENTER or Geofence.GEOFENCE_TRANSITION_EXIT)
                    .build()
            )
        }
        geofencingClient.addGeofences(getGeofencingRequest(), geofencePendingIntent)?.run {
            addOnSuccessListener {
                Log.d("costam","nibydodalo")
            }
            addOnFailureListener {
                Log.d("costam",it.toString())
            }

        }



    }
    private fun getGeofencingRequest(): GeofencingRequest {
        Log.d("sciezka","getGeofencingRequest")
        return GeofencingRequest.Builder().apply {
            setInitialTrigger(GeofencingRequest.INITIAL_TRIGGER_ENTER)
            addGeofences(geofenceList)
        }.build()
    }
    private fun showTrafficTime(){
        Log.d("korek",trafficTime.toString())
    if(trafficTextView!=null)
        trafficTextView.text=trafficTime.toString()
    }
    private fun getTimeInTrafficUrl():String{
        var path="https://maps.googleapis.com/maps/api/directions/json?origin="
        path=path+routepoints.get(0).latitude.toString()+","+routepoints.get(0).longitude.toString()
        path=path+"&destination="
        path=path+routepoints.get(routepoints.size-1).latitude.toString()+","+routepoints.get(routepoints.size-1).longitude.toString()+"&waypoints="
        for (i in 0 until routepoints.size-1)
        {
            path=path+"via:"+routepoints.get(0).latitude.toString()+","+routepoints.get(0).longitude.toString()
            if(i+1<routepoints.size-1){
                path=path+"|"
            }
        }
        path=path+"&traffic_model=best_guess&departure_time=now&key=AIzaSyDJjXbdWCBeo9c0DScOtf5weOLLZuxzBB0"
        Log.d("traffic",path)
            return path
    }

    private fun fetchPointsFromDatabase(routeid:Int){
        Log.d("sciezka","fetchPointsFromDatabase")
        var databaseref = FirebaseDatabase.getInstance().getReference("Routes/$routeid/points")
        databaseref.addListenerForSingleValueEvent(object: ValueEventListener {
            override fun onCancelled(p0: DatabaseError) {

            }
            override fun onDataChange(p0: DataSnapshot) {
                p0.children.forEach {
                    val singleroutepoint=it.getValue(Point::class.java)
                    routepoints.add(LatLng(singleroutepoint!!.latitude,singleroutepoint.longitude))
                }
                val URL=getTimeInTrafficUrl()
                GetTrafficTime(URL).execute()
                googleMap!!.moveCamera(CameraUpdateFactory.newLatLngZoom(routepoints.get(0), 16f))

            }

        })
        databaseref=FirebaseDatabase.getInstance().getReference("Routes/$routeid/places")
        databaseref.addListenerForSingleValueEvent(object:ValueEventListener{
            override fun onCancelled(p0: DatabaseError) {

            }

            override fun onDataChange(p0: DataSnapshot) {
                p0.children.forEach {
                    val singleplace=it.getValue(Place::class.java)
                    if (singleplace != null) {
                        places.add(singleplace)
                    }

                }
                addGeoFencingToMap()


            }


        })



    }
    private fun showDistance(location:LatLng){

        var distance=PolyUtil.distanceToLine(location,routepoints.get(0),routepoints.get(1))
        for (i in 0 until routepoints.size)
        {
        if(i+1<routepoints.size && PolyUtil.distanceToLine(location,routepoints.get(i),routepoints.get(i+1))<distance){
            distance=PolyUtil.distanceToLine(location,routepoints.get(i),routepoints.get(i+1))
        }
        }

        if(distanceTextView!=null) {
            if (distance > 20)
                distanceTextView.text = "Odleglosc od trasy: " + distance.roundToInt().toString()+"m"
            else
                distanceTextView.text = "Jestes na trasie"
        }
    }

    fun drawRoutePolyline() {
        Log.d("sciezka","drawRoutePolyline")

        val options = PolylineOptions().width(5f).color(Color.BLUE).geodesic(true)

        for (i in 0 until routepoints.size)
        {
            val point = routepoints.get(i)
            options.add(point)


        }

        routeline = googleMap!!.addPolyline(options)
    }
    fun drawOffRouteLine(current:LatLng?=null) {
        Log.d("sciezka","drawRoutePolyline")
        offRouteLine?.remove()
        val options = PolylineOptions().width(5f).color(Color.BLUE).geodesic(true)
        if (current != null) {
            offRoutePoints.add(current)
        }
            for (i in offRoutePoints)
                options.add(i)

            offRouteLine = googleMap!!.addPolyline(options)



    }

    private fun redrawLine(current:LatLng) {
        line?.remove()
        line?.points?.clear()
        val options = PolylineOptions().width(10f).color(Color.RED).geodesic(true)
        var results=FloatArray(10)
        Location.distanceBetween(routepoints.get(0).latitude,routepoints.get(0).longitude,current.latitude,current.longitude,results)
        var smallest=results[0]
        var place=0
        for (i in 0 until routepoints.size)
        {
            Location.distanceBetween(routepoints.get(i).latitude,routepoints.get(i).longitude,current.latitude,current.longitude,results)
            if(results[0]<smallest){
                smallest=results[0]
                place=i
            }
        }

        for (i in 0 until place)
        {

            val point = routepoints.get(i)
            options.add(point)

        }
        options.add(current)
        line = googleMap!!.addPolyline(options) //add Polyline
        

    }

    @SuppressLint("MissingPermission")
    private fun getLocation(){
        Log.d("sciezka","getLocation")
        var locationGps : Location?=null
        var locationNetwork : Location?=null
        var hasGps=false
        var hasNetwork=false
        val locationmanager=thisactivity!!.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        hasGps=locationmanager.isProviderEnabled(LocationManager.GPS_PROVIDER)
        hasNetwork=locationmanager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)
        val mypreference=MyPreference(thisactivity!!)
        var followed=mypreference.getFollowUser()
        Log.d("sprawdz",locationmanager.toString())
        if(hasGps||hasNetwork){
            if(hasGps){

                locationmanager.requestLocationUpdates(LocationManager.GPS_PROVIDER,5000,0F,object: LocationListener {
                    override fun onLocationChanged(location: Location?) {

                        if (location != null) {
                            locationGps = location
                            val temp=LatLng(locationGps!!.latitude,locationGps!!.longitude)
                            if (routepoints.isNullOrEmpty()==false && PolyUtil.isLocationOnPath(
                                    temp,
                                    routeline?.points,
                                    false,
                                    10.0
                                )
                            ) {
                                points.add(temp)
                                redrawLine(temp)
                            }
                            if (routepoints.isNotEmpty()) {
                                showDistance(temp)
                            }
                            followed=mypreference.getFollowUser()
                            if(followed){
                                drawOffRouteLine(temp)
                            }
                            else offRouteLine?.remove()
                            Log.d("CodeAndroidLocation","GPS Latitude:"+locationGps!!.latitude)
                            Log.d("CodeAndroidLocation","GPS Longitude:"+locationGps!!.longitude)
                        }
                    }

                    override fun onStatusChanged(p0: String?, p1: Int, p2: Bundle?) {
                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                    }

                    override fun onProviderEnabled(p0: String?) {
                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                    }

                    override fun onProviderDisabled(p0: String?) {
                        TODO("not implemented") //To change body of created functions use File | Settings | File Templates.
                    }

                })
                val localGpsLocation=locationmanager.getLastKnownLocation(LocationManager.GPS_PROVIDER)
                if(localGpsLocation!=null){
                    locationGps=localGpsLocation
                }
                if(hasNetwork){
                    Log.d("CodeAndroidLocation","hasGps")
                    locationmanager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER,5000,0F,object:
                        LocationListener {
                        override fun onLocationChanged(location: Location?) {
                            if(location!=null){
                                locationNetwork=location
                                val temp=LatLng(locationNetwork!!.latitude,locationNetwork!!.longitude)
                                    if (routepoints!=null && PolyUtil.isLocationOnPath(
                                            temp,
                                            routeline?.points,
                                            false,
                                            10.0
                                        )
                                    ) {
                                        points.add(temp)
                                        redrawLine(temp)
                                    }
                                    if (routepoints.isNotEmpty()&&temp!=null) {
                                        showDistance(temp)
                                    }
                                followed=mypreference.getFollowUser()
                                    if(followed){
                                        drawOffRouteLine(temp)
                                    }
                                    else offRouteLine?.remove()
                                Log.d("CodeAndroidLocation","Network Latitude:"+locationNetwork!!.latitude)
                                Log.d("CodeAndroidLocation","Network Latitude:"+locationNetwork!!.longitude)
                            }
                        }

                        override fun onStatusChanged(p0: String?, p1: Int, p2: Bundle?) {
                        }

                        override fun onProviderEnabled(p0: String?) {
                        }

                        override fun onProviderDisabled(p0: String?) {
                        }

                    })
                    val localNewtorkLocation=locationmanager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                    if(localNewtorkLocation!=null){
                        locationNetwork=localNewtorkLocation
                    }
                    if(locationGps!=null && locationNetwork!=null){
                        if(locationGps!!.accuracy>locationNetwork!!.accuracy){
                            Log.d("CodeAndroidLocation","Network Latitude:"+locationNetwork!!.latitude)
                            Log.d("CodeAndroidLocation","Network Latitude:"+locationNetwork!!.longitude)

                        }
                        else{
                            Log.d("CodeAndroidLocation","GPS Latitude:"+locationGps!!.latitude)
                            Log.d("CodeAndroidLocation","GPS Latitude:"+locationGps!!.longitude)
                        }
                    }
                }
            }
        }
        else{
            startActivity(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
        }
    }





    fun getDirectionUrl(origin:LatLng,dest:LatLng):String{
        Log.d("sciezka","getDirectionUrl")
        return "https://maps.googleapis.com/maps/api/directions/json?origin=${origin.latitude},${origin.longitude}&destination=${dest.latitude},${dest.longitude}&key=AIzaSyDJjXbdWCBeo9c0DScOtf5weOLLZuxzBB0"
    }
    fun getRoutePoints(){
        Log.d("sciezka","getRoutePoints")
        var pointstostring=""
        for (i in 0 until routepoints.size){
            pointstostring=pointstostring+routepoints.get(i).latitude.toString()+","+routepoints.get(i).longitude
            if(i+1<routepoints.size)
                pointstostring=pointstostring+"|"
        }
        routepoints.clear()
        GetRoutePolyline("https://roads.googleapis.com/v1/snapToRoads?path=$pointstostring&interpolate=true&key=AIzaSyDJjXbdWCBeo9c0DScOtf5weOLLZuxzBB0").execute()

    }
    inner class GetRoutePolyline(val url: String) : AsyncTask<Void, Void, MutableList<LatLng>>() {


        override fun doInBackground(vararg p0: Void?): MutableList<LatLng> {
            Log.d("sciezka","GetRoutePolyline")
            val client = OkHttpClient()

            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            val data = response.body!!.string()

            try {
                val resObj = Gson().fromJson(data, GoogleMapRoute::class.java)
                Log.d("pokazmy",data)
                for (i in 0..(resObj.snappedPoints.size - 1)) {
                    routepoints.add(
                        LatLng(
                            resObj.snappedPoints[i].location.latitude,
                            resObj.snappedPoints[i].location.longitude
                        )
                    )
                }

            } catch (e: Exception) {
                e.printStackTrace()
            }
            Log.d("pokazmy",routepoints.size.toString())
            return routepoints
        }

        override fun onPostExecute(routepoints: MutableList<LatLng>?) {
            Log.d("sciezka","onPostExecute")
            drawRoutePolyline()
            getLocation()

        }


    }
    inner class GetTrafficTime(val url: String) : AsyncTask<Void, Void, Int>() {


        override fun doInBackground(vararg p0: Void?): Int {
            Log.d("sciezka","GetRoutePolyline")
            val client = OkHttpClient()

            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            val data = response.body!!.string()
            var traffictime=0
            try {
                val resObj = Gson().fromJson(data, GoogleMapTraffic::class.java)
                traffictime=resObj.routes.get(0).legs.get(0).duration_in_traffic.value
                Log.d("traffic",resObj.routes.get(0).legs.get(0).duration_in_traffic.value.toString())
            } catch (e: Exception) {
                e.printStackTrace()
            }

            return traffictime/60
        }

        override fun onPostExecute(trafficTimetemp:Int) {
            Log.d("sciezka","onPostExecute")
            if(trafficTimetemp!=null) {
                trafficTime=trafficTimetemp
                showTrafficTime()
            }
                getRoutePoints()

        }


    }



}

