package com.example.ideokonkurs.fragments

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.ideokonkurs.R
import com.example.ideokonkurs.RouteRecyclerAdapter
import com.example.ideokonkurs.TopSpacingItemDecoration
import com.example.ideokonkurs.models.RouteItem
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener
import okhttp3.Route

class RoutesFragment: Fragment() {
    internal var root: View? = null
    private lateinit var routeAdapter:RouteRecyclerAdapter
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {
        root = inflater.inflate(R.layout.fragment_routes, container, false)
        loadRoutes()
        return root
    }


    fun loadRoutes(){
        val recyclerview=root!!.findViewById(R.id.routesRecyclerView) as RecyclerView
        recyclerview.layoutManager= LinearLayoutManager(activity)
        routeAdapter= RouteRecyclerAdapter()
        val topspacingdecoration=TopSpacingItemDecoration(30)
        recyclerview.addItemDecoration(topspacingdecoration)
        var list = ArrayList<RouteItem>()
        var databaseref = FirebaseDatabase.getInstance().getReference("Routes/")

        databaseref.addListenerForSingleValueEvent(object:ValueEventListener{
            override fun onCancelled(p0: DatabaseError) {

            }

            override fun onDataChange(p0: DataSnapshot) {
                p0.children.forEach {
                    val routeit=it.getValue(RouteItem::class.java)
                    list.add(routeit!!)

                }
                routeAdapter.submitList(list)
                recyclerview.adapter=routeAdapter
            }

        })
    }
}