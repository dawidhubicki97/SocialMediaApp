package com.example.ideokonkurs.models

import com.google.gson.annotations.SerializedName

data class GoogleMapRoute (
    @SerializedName("snappedPoints") val snappedPoints : List<SnappedPoints>
)
data class SnappedPoints (

    @SerializedName("location") val location : Location,
    @SerializedName("originalIndex") val originalIndex : Int,
    @SerializedName("placeId") val placeId : String
)
data class Location (

    @SerializedName("latitude") val latitude : Double,
    @SerializedName("longitude") val longitude : Double
)